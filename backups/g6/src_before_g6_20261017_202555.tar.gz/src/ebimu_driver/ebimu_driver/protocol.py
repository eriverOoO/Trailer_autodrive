"""EBIMU-9DOFV6 rev10 printed p12/20/21: ASCII Euler then gyro DPS."""
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class Sample:
    roll:float;pitch:float;yaw:float;gx:float;gy:float;gz:float
    ax:float=None;ay:float=None;az:float=None
    @property
    def euler_rad(self):return tuple(math.radians(x) for x in (self.roll,self.pitch,self.yaw))
    @property
    def gyro_rad_s(self):return tuple(math.radians(x) for x in (self.gx,self.gy,self.gz))

class AsciiParser:
    def __init__(self,max_frame=256,include_acceleration=False):
        self.include_acceleration=include_acceleration;self.buffer=bytearray();self.max_frame=max_frame;self.accepted=0;self.rejected=0;self.discarded=0
    def feed(self,data):
        self.buffer.extend(data);out=[]
        while self.buffer:
            start=self.buffer.find(b'*')
            if start<0:self.discarded+=len(self.buffer);self.buffer.clear();break
            if start:self.discarded+=start;del self.buffer[:start]
            end=self.buffer.find(b'\n');restart=self.buffer.find(b'*',1)
            if restart>=0 and (end<0 or restart<end):self.rejected+=1;del self.buffer[:restart];continue
            if end<0:
                if len(self.buffer)>self.max_frame:self.rejected+=1;self.buffer.clear()
                break
            frame=bytes(self.buffer[:end+1]);del self.buffer[:end+1]
            try:
                if len(frame)>self.max_frame or not frame.endswith(b'\r\n'):raise ValueError('framing')
                parts=frame[1:-2].decode('ascii').split(',')
                if len(parts)!=(9 if self.include_acceleration else 6):raise ValueError('configured channel count mismatch; disable all other outputs')
                if any(not p.strip() for p in parts):raise ValueError('empty value')
                vals=tuple(float(p) for p in parts)
                if not all(math.isfinite(v) for v in vals):raise ValueError('nonfinite')
                if abs(vals[0])>180 or abs(vals[1])>90 or abs(vals[2])>180:raise ValueError('Euler range')
                out.append(Sample(*vals));self.accepted+=1
            except (ValueError,UnicodeDecodeError):self.rejected+=1
        return out

QUERY_COMMANDS={'configuration':'<cfg>','version':'<ver>'}
# Explicit only. Extra channels OFF are necessary to guarantee six-field framing.
CONFIG_COMMANDS=('<sem0>','<soc1>','<sof1>','<sog1>','<soa0>','<som0>','<sod0>','<sot0>','<sots0>','<sor10>')
GYRO_CALIBRATION='<cg>'
