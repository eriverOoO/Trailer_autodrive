from pathlib import Path
import shutil,yaml,json,hashlib
W=Path(__file__).resolve().parents[1];P=W/'src/mvsim_slam_real_bringup';C=P/'config';C.mkdir(exist_ok=True);(P/'launch').mkdir(exist_ok=True);(P/'rviz').mkdir(exist_ok=True)
def save(n,d): (C/n).write_text(yaml.safe_dump(d,sort_keys=False,allow_unicode=True))
g={'status':'PROVISIONAL — measure before actuation','tractor_length':.97,'tractor_width':.585,'trailer_length':.97,'trailer_width':.585,'tractor_wheelbase':.58,'tractor_rear_axle_position':[-.29,0.,0.],'tractor_steering_axis':[.29,0.,0.],'trailer_axle_position':[-.29,0.,0.],'hitch_position':[-.545,0.,0.],'hitch_to_axle_distance':.835,'connection_length':.12,'maximum_steering_angle':.45,'steering_rate_limit':.9,'forward_velocity':.14,'reverse_velocity':.08775,'lidar_mounting_offset':[0.,0.,.35,0.,0.,0.],'tractor_imu_offset':[.25,0.,.25,0.,0.,0.],'trailer_imu_offset':[.25,0.,.25,0.,0.,0.],'initial_articulation_rad':0.,'initial_alignment_confirmed':False,'trailer_gyro_bias_rad_s':0.,'trailer_bias_confirmed':False}
save('vehicle_geometry.yaml',g)
save('lidar.yaml',{'lidar_gateway':{'ros__parameters':{'input_topic':'/lidar_raw','output_topic':'/scan','frame_id':'laser_frame','angle_offset':0.,'reverse_direction':False,'timeout':.5}},'rplidar_source':{'ros__parameters':{'port':'','enable_device':False,'frame_id':'laser_frame','bins':720,'range_min':.15,'range_max':12.,'clockwise':True}}})
save('imu.yaml',{'tractor_imu':{'ros__parameters':{'port':'','enable_device':False,'frame_id':'tractor_imu_link','output_topic':'/tractor/imu/data','mounting_rpy':[0.,0.,0.],'publish_orientation':True,'timeout':.2,'baud':115200}},'trailer_imu':{'ros__parameters':{'port':'','enable_device':False,'frame_id':'trailer_imu_link','output_topic':'/trailer/imu/data','mounting_rpy':[0.,0.,0.],'publish_orientation':True,'timeout':.2,'baud':115200}}})
save('controller.yaml',{'control_adapter':{'ros__parameters':{'enable_actuation':False,'motor_scale_pwm_per_m_s':1000.,'motor_scale_confirmed':False,'steering_sign':-1.,'left_motor_sign':1.,'right_motor_sign':1.,'polarity_confirmed':False,'command_timeout':.25,'state_timeout':.25,'require_tractor_imu':True,'max_pwm':255}}})
save('parking.yaml',{'tractor_parallel_parking_auto':{'ros__parameters':{'auto_execute':True,'execute_parking':True,'auto_detect_target':True,'enable_pose_freshness_stop':True,'parking_stop_policy':'legacy','slot_length':6.2,'slot_width':2.1,'search_speed':.14,'parking_speed_factor':1.755,'completion_hinge_deg':6.25,'completion_settle_max_s':8.,'planner_timeout':90.,'beam_gap_filling':True,'max_replans':3}}})
save('hardware.yaml',{'enable_actuation':False,'arduino_port':'','lidar_model':'UNDECIDED','imu_model':'E2BOX EBIMU-9DOFV6','tractor_imu_port':'','trailer_imu_port':'','hardware_verified':False})
save('slam.yaml',{'cartographer_node':{'ros__parameters':{'use_sim_time':False}},'cartographer_occupancy_grid_node':{'ros__parameters':{'use_sim_time':False}}})
O=Path('/home/venezuelachocolatemilk/mvsim_slam/mvsim_slam_final/config')
for p in O.glob('*.lua'):shutil.copy2(p,C/p.name)
p=C/'reference_lidar_only.lua';text=p.read_text();(C/'reference_imu_optional.lua').write_text(text.replace('TRAJECTORY_BUILDER_2D.use_imu_data = false','TRAJECTORY_BUILDER_2D.use_imu_data = true'))
(W/'ARCHITECTURE.md').write_text('''# Architecture

Original packages (7) are copied intact, including vision resources and firmware outside packages. New packages: ebimu_driver (UART parser/configuration CLI/two nodes); real_vehicle_bridge (standard scan gateway, optional original RPLidar library source, static TF, articulated estimator, control adapter); real_parking (unchanged final B modules plus native C++ optimizer built locally, independent diagnostic entries and original AutoParking); mvsim_slam_real_bringup (YAML/Lua/launch/RViz).

`map → odom → base_footprint` is published solely by Cartographer. base_footprint is the provisional tractor BODY CENTER. Static children: base_link (same), laser_frame, tractor_imu_link; dynamic child trailer_link is the trailer BODY CENTER inferred from hitch and integrated trailer yaw. Trailer IMU is a static child of trailer_link. local_map is an identity static child of map, retaining the B interface convention.

Planner state [x,y,tractor_yaw,trailer_yaw] uses tractor REAR AXLE, not scan center. Body/axle/hitch offsets are transformed explicitly. Original trailer footprint convention is relative to HITCH; new geometry conversion constructs identical-size rectangular bodies (.97 x .585m) in appropriate frames. Independent positions/distances must satisfy geometric consistency; configuration rejects contradictions.

Maps: Cartographer /map is unchanged. /parking/detection_map preserves observed/unknown evidence, and /tractor/localization/local_map feeds B collision checks. Scan-derived free-space augmentation uses stamped TF at the scan time, configured lidar offset and original .15m no-hit margin; it never erases occupied cells. Unknown/outside remain blocked. Hardware state is invalid until actual fresh SLAM matching, scan and both IMUs exist, with explicit yaw alignment/bias acknowledgment.

AutoParking retains Final B detector, C/D/E scheduler, steering-priority, clearance+shot+resume20, LQR and state transitions. Its Geometry.from_world factory is adapted externally to validated YAML; copied algorithm files remain unchanged. Integrated LQR outputs Twist yaw rate; external adapter recovers steering with atan(wheelbase*omega/v), clamps/rate-limits/quantizes steering, and maps signed speed to provisional PWM. Preview commands are isolated on /parking/motion_preview; hardware commands require all explicit gates. Legacy vision motion planner is never included in new launch.

Development mode launches software nodes without opening ANY device and reports unavailable hardware, never fabricated sensor success. Optional synthetic test fixtures exist only under tests/ and verification/. Original launch_pkg/main.launch.py may drive hardware and is not a development command.
''')
b=json.loads((W/'source_baseline.json').read_text());root=O.parents[1]
for folder in [root/'mvsim_slam_final/src/parking_system',root/'mvsim_slam_final/src/optimizer']:
 for p in folder.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.so']:b[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
(W/'source_baseline.json').write_text(json.dumps(b,indent=2))
